# Dinosaur-Game
This is a simple Infinite Running game made with Unity 5.4. Basically this is the android version of chromes famous offline dinosaur game. Feel Free to Fork to learn how it's done and modify as you want.Cheers!!

Download Games .apk from [here](https://drive.google.com/open?id=0B0NbfE3wLOeMUXZVTGpNWEN5ajA)

# Here is a short demo of My Game
[![Dinosaur Game Demo](https://img.youtube.com/vi/FPOW468pb5c/0.jpg)](https://www.youtube.com/watch?v=FPOW468pb5c)
